package com.localbook.model;

public enum AppointmentStatus {
    
    CONFIRMED,
    COMPLETED,
    CANCELED
}
