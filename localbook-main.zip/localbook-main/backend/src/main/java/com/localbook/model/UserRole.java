package com.localbook.model;
public enum UserRole {
    ADMIN,
    BUSINESS_OWNER,
    CLIENT
}